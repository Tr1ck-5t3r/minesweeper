import './App.css';
import React from 'react'
import Board from './Components/Game-components/Board';
function App() {
  return (
    <div>
      <div className="aligned">   
        <Board/>
      </div>
    </div>
  );
}

export default App
